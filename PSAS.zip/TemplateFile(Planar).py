,#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jul  6 19:37:16 2020

@author: jim53
"""

from IPython import get_ipython
import numpy as np
from Model import Model
from PlotModel import PlotModel
#get_ipython().magic('reset -sf')
from Analyze import Analyze
from GMread import GMread

ModelSet=['Planar','line']
#Number and define NODE locations
NODE=[]
NODE.insert(0,[0,0])
NODE.insert(1,[2.5,0])
NODE.insert(2,[5,0])
NODE.insert(3,[7.5,0])
NODE.insert(4,[10,0])

CON=[[1,2],[2,3],[3,4],[4,5]]

#Turn selfweight on and off
selfweight=0

#Add nodal masses
Node_Mass=[1,1,1,1,1]

# DO NOT EDIT THIS
Model=Model(NODE,CON,Node_Mass,selfweight,ModelSet)

#Set the Boundary conditions at the nodes where there are boundaries.
#Others will have no BC

Model.BOUN[0]=[1,1,1];
Model.BOUN[4]=[1,1,1];

#USER Define loading
Model.LOAD[2]=[0,-100,0]

#DO NOT EDIT THIS
# Given Node Locations, connectivity, Element Type, BC, and Loading, initiates elements
el=Model.init_el()

# USER Define E A and I, releases, q0 and w here

#w is defined as positive outwards and negative into the beam
#Order of basic forces is [axial, torsion, Myi,Myj,Mzi,Mzj]

for i in range (Model.numel):
    el[i].Iy=20000
    el[i].Iz=10000
    el[i].A=1000
    el[i].E=1
    el[i].G=1/(2*1+.3)
    el[i].J=1
    el[i].rho=0.001

#el[2].REL=[np.inf,np.inf,np.inf,np.inf,np.inf,np.inf,np.inf,np.inf,np.inf,np.inf,np.inf,np.inf];


#DO NOT EDIT
el=Model.elMat(el)
Model.Create_B(el)
Model.Create_K()
Model.Create_M()


Ground_Motion='GM1.txt'
DynOp=[.25,.5,.01,[1,0,0]]
#DO NOT EDIT
el=Model.elMat(el)
An=Analyze()

#Static Analysis
An.Displ(Model,el)

#Dynamic analysis
Model.Eig()
Model.Create_C("Rayleigh",[0,1,5])
#GM=GMread(Ground_Motion)
P = Model.P
P = np.tile(P,(1,1000))
[Model.Udy,Model.U_dotdy,Model.U_ddotdy]=An.Dyn_Newmark(Model,DynOp,P,[])




plot=PlotModel()
plot.Struct(Model,el)
plot.DefShape(Model,el)
animation = plot.AnimateDefShape(Model,el,1)



plot=PlotModel()
plot.Struct(Model,el)
plot.DefShape(Model,el)
